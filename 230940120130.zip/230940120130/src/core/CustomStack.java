package core;

import custome_exception.InvalidStackOperationException;

public class CustomStack {
	
	private int top;
	private int[] stack;
	
	
	//create a new array
	public CustomStack(int size)
	{
		top=-1;
		stack=new int[size];
	}
	
	
	//check if stack is full or not(top==stack.length-1)
	public boolean isFull()
	{
		if(top==stack.length-1)
			return true;
		else
			return false;
	}
	
	
	//check if stack is empty or not(top==-1)
	public boolean isEmpty()
	{
		if(top==-1)
			return true;
		else
			return false;
	}
	
	//push integers onto the stack
	public void push(int x)
	{
		//checking whether stack is full, if true then throw appropriate exception
		if(isFull())
			throw new InvalidStackOperationException("Stack is FULL!!!! Can't Push Element....");
		else 
		{
			top=top+1;
			stack[top]=x;
		}
	}
	
	
	//remove(pop) element from stack
	public int pop()
	{
		//checking whether stack is empty, if true then throw appropriate exception
		if(isEmpty())
		{
			throw new InvalidStackOperationException("Stack is EMPTY!!!! Can't Pop Element");
		}
		int data=stack[top];
		stack[top]=0;
		top=top-1;
		return data;
	}
	
	
	//retrieve the top element from stack 
	public int top()
	{
		//checking whether stack is empty, if true then throw appropriate exception
		if(isEmpty())
			throw new InvalidStackOperationException("Stack is EMPTY!!!! Can't retrieve top element.....");
		else
			return stack[top];
	}
	
	
	//retrieve the maximum element from stack
	public int max()
	{
		int max;
		//checking whether stack is empty, if true then throw appropriate exception
		if(isEmpty())
			throw new InvalidStackOperationException("Stack is EMPTY!!!! Can't retrieve max element.....");
		
		else
		{
			max=stack[0];
			for(int i=1;i<=top;i++)
			{
				if(stack[i]>max)
				{
					max=stack[i];
				}
			}
			return max;
		}
	}

}

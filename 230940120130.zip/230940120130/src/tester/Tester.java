package tester;

import java.util.Scanner;
import core.*;
public class Tester {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		boolean exit=false;
		
		
		System.out.println("Enter Size Of Stack: ");
		int n= sc.nextInt();
		CustomStack IntStack= new CustomStack(n);
		
		while(!exit)
		{
			System.out.println("Menu: ");
			System.out.println("1.Push Element");
			System.out.println("2.Pop Element");
			System.out.println("3.Top Element");
			System.out.println("4.Get Maximum Element");
			System.out.println("0.Exit");
			System.out.println("Select Option: ");
			System.out.println();
			try 
			{
				switch(sc.nextInt())
				{
				
					case 1:
						System.out.print("Enter Element: ");
						IntStack.push(sc.nextInt());
						System.out.println("Element Inserted Successfully!!!...");
						break;
						
					case 2:
						int element=IntStack.pop();
						System.out.println("Popped Element From Stack: "+element);
						break;
						
					case 3:
						element=IntStack.top();
						System.out.println("Top Element From Stack: "+element);
						break;
						
					case 4:
						element=IntStack.max();
						System.out.println("Maximum Element From Stack: "+element);
						break;
						
					case 0:
						exit=true;
						System.out.println("Exited From Program..");
						break;
						
				}
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
		sc.close();
	}

}

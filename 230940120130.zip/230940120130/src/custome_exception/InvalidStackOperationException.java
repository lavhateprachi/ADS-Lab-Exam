package custome_exception;

public class InvalidStackOperationException extends RuntimeException{
	
	
	//creating a custom exception by extending RuntimeException
	public InvalidStackOperationException(String msg) {
		super(msg);
	}

}
